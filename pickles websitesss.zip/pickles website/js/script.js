
/* ==========================================
   VINAYAKA PICKLES - WEBSITE FUNCTIONALITY
========================================== */

/*
   IMPORTANT:
   Replace this placeholder with your real WhatsApp
   number, including country code, without + or spaces.

   Example format: 919876543210
*/
const WHATSAPP_NUMBER = "91";

/*
   Sample prices are for 250g.
   Change these values to your actual prices.
*/
const products = [
    // VEG PICKLES
    {
        id: 1,
        name: "Mango Pickle",
        category: "veg",
        price: 120,
        description: "Classic Andhra raw mango pickle.",
        badge: "Bestseller",
        image: "https://t3.ftcdn.net/jpg/07/65/71/36/360_F_765713660_lcK6YxresC9Z7aTLNRYjZux2Fcl7TjPV.jpg"
    },
    {
        id: 2,
        name: "Ginger Pickle",
        category: "veg",
        price: 130,
        description: "A bold, tangy ginger speciality.",
        badge: "Traditional",
        image: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcT7-dSvBwIkkddZMgMLV0rjkS5Vhdp-_NdJbjVuyjxdg4I_s-9uwmyY2tM&s=10"
    },
    {
        id: 4,
        name: "Usiri Pickle",
        category: "veg",
        price: 125,
        description: "Traditional usiri with spicy seasoning.",
        badge: "Traditional",
        image: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTKtVVS_aSIvO86WbqIHzUKIwqVIZmN3GejlU0TT0ou7y99oye5CyPTCJLy&s=10"
    },
    {
        id: 5,
        name: "Lemon Pickle",
        category: "veg",
        price: 110,
        description: "A zesty pickle with a tangy finish.",
        badge: "Tangy",
        image: "https://freshggies.in/cdn/shop/files/LemonPickleFGPICK03.jpg?v=1745379762"
    },
    {
        id: 6,
        name: "Dhosakaya Pickle",
        category: "veg",
        price: 120,
        description: "A classic Andhra yellow cucumber pickle.",
        badge: "Andhra Special",
        image: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTwZXOVXEjUq8ka1k5LG2cg4jlHq7eyg8QpF-VpHu6ekNFy35Z2sBB8yI0&s=10"
    },
    {
        id: 7,
        name: "Vankaya Pickle",
        category: "veg",
        price: 130,
        description: "Brinjal pickle with traditional spices.",
        badge: "Traditional",
        image: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSj6lSXkhYuuF83sWuEIPeB1PhHUiAgm6DgIhKtoUHoUpfpZ0ntl21YYr5j&s=10"
    },
    {
        id: 8,
        name: "Gongura Pickle",
        category: "veg",
        price: 125,
        description: "A tangy sorrel-leaf Andhra favourite.",
        badge: "Andhra Favourite",
        image: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRbdTodoksO9OiZa8gd8mgdPoo40LllriW7LtIzPrnF5pX0s9gwT-ELcT8&s=10"
    },
    {
        id: 9,
        name: "Red Chilli Pickle",
        category: "veg",
        price: 120,
        description: "A fiery pickle for spice lovers.",
        badge: "Spicy",
        image: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTpOyyoZ-VM4-0PcG95ExjsHUnV4bm0KzZdirYY306SMq_tJiv_ApZa4Ks&s=10"
    },
    {
        id: 10,
        name: "Sweet Mango Pickle",
        category: "veg",
        price: 130,
        description: "Sweet, tangy and gently spiced mango.",
        badge: "Sweet & Tangy",
        image: "https://vellankifoods.com/cdn/shop/products/sweet_mango_pickle_bellam_avakaya_pickles.jpg?v=1680181742"
    },

    // NON-VEG PICKLES
    {
        id: 11,
        name: "Chicken Pickle",
        category: "nonveg",
        price: 250,
        description: "Spicy chicken pickle with Andhra flavours.",
        badge: "Popular",
        image: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTwCNrrsn6F3AjY5D7BHo0wSmM2gkn9o_sl3zn750Rg6SFdOcajucHemwM&s=10"
    },
    {
        id: 12,
        name: "Mutton Pickle",
        category: "nonveg",
        price: 350,
        description: "Rich, spicy mutton pickle speciality.",
        badge: "Special",
        image: "https://bhimavarampickels.com/wp-content/uploads/2025/03/mutton-pickle-2.webp"
    },
    {
        id: 13,
        name: "Prawn Pickle",
        category: "nonveg",
        price: 300,
        description: "A coastal-style prawn pickle.",
        badge: "Seafood",
        image: "https://akshayanonvegpickles.com/wp-content/uploads/2025/06/DSC07837-scaled.webp"
    },
    {
        id: 14,
        name: "Gongura Chicken",
        category: "nonveg",
        price: 280,
        description: "Chicken paired with tangy gongura.",
        badge: "Andhra Special",
        image: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRs42OwiShsYSTeW7cc3H-iqhtp2FKa5bLDYs1wsGAIaG0eSGUfJvlbluNd&s=10"
    },
    {
        id: 15,
        name: "Gongura Mutton",
        category: "nonveg",
        price: 380,
        description: "A bold combination of mutton and gongura.",
        badge: "Special",
        image: "https://minnieintiruchulu.com/wp-content/uploads/2024/08/Untitled-design-2026-01-04T154720.692.png"
    },
    {
        id: 16,
        name: "Chicken Thokku",
        category: "nonveg",
        price: 250,
        description: "A flavourful, spicy chicken thokku.",
        badge: "Traditional",
        image: "https://desindesi.com/cdn/shop/files/chicken_thokku.jpg?v=1764648425"
    },

    // EXTRA PODIS
    {
        id: 17,
        name: "Munagaku Podi",
        category: "podis",
        price: 100,
        description: "Drumstick-leaf powder for everyday meals.",
        badge: "Traditional",
        image: "https://kalaguragampa.com/_next/image?url=https%3A%2F%2Fmanage.kalaguragampa.com%2Fapp-images%2Fuuid%2F0fe09176-7119-4d12-8a98-c48d4e323e89&w=3840&q=75"
    },
    {
        id: 18,
        name: "Karam Podi",
        category: "podis",
        price: 90,
        description: "A spicy Andhra-style seasoning powder.",
        badge: "Spicy",
        image: "https://rajamahendravarampickles.com/wp-content/uploads/2026/05/ChatGPT-Image-May-7-2026-03_20_24-PM.png"
    }
];

/* ==========================================
   1. ELEMENTS AND STATE
========================================== */

const productGrid = document.getElementById("productGrid");
const categoryFilters = document.getElementById("categoryFilters");
const resultsText = document.getElementById("resultsText");
const sortProducts = document.getElementById("sortProducts");

const cartButton = document.getElementById("cartButton");
const cartCount = document.getElementById("cartCount");
const cartSection = document.getElementById("cartSection");
const cartItems = document.getElementById("cartItems");
const cartSubtotal = document.getElementById("cartSubtotal");
const checkoutButton = document.getElementById("checkoutButton");
const closeCart = document.getElementById("closeCart");

const menuToggle = document.getElementById("menuToggle");
const navigation = document.getElementById("navigation");
const toast = document.getElementById("toast");

let activeCategory = "all";
let cart = [];
let toastTimer;

/* ==========================================
   2. HELPER FUNCTIONS
========================================== */

function formatPrice(amount) {
    return new Intl.NumberFormat("en-IN", {
        style: "currency",
        currency: "INR",
        maximumFractionDigits: 2
    }).format(amount);
}

function getPackMultiplier(size) {
    const multipliers = {
        "250g": 1,
        "500g": 1.9,
        "1kg": 3.6
    };

    return multipliers[size] || 1;
}

function getPackPrice(product, size) {
    return Math.round(product.price * getPackMultiplier(size));
}

function showToast(message) {
    clearTimeout(toastTimer);

    toast.textContent = message;
    toast.classList.add("show");

    toastTimer = setTimeout(() => {
        toast.classList.remove("show");
    }, 2500);
}

/* ==========================================
   3. PRODUCT DISPLAY
========================================== */

function renderProducts() {
    let filteredProducts = products.filter(product => {
        return activeCategory === "all" ||
               product.category === activeCategory;
    });

    const sortValue = sortProducts.value;

    if (sortValue === "low") {
        filteredProducts.sort((a, b) => a.price - b.price);
    } else if (sortValue === "high") {
        filteredProducts.sort((a, b) => b.price - a.price);
    } else if (sortValue === "name") {
        filteredProducts.sort((a, b) =>
            a.name.localeCompare(b.name)
        );
    }

    resultsText.textContent =
        `Showing ${filteredProducts.length} product` +
        `${filteredProducts.length === 1 ? "" : "s"}`;

    productGrid.innerHTML = "";

    if (filteredProducts.length === 0) {
        productGrid.innerHTML = `
            <div class="empty-products">
                <h3>No products found</h3>
                <p>Please choose another category.</p>
            </div>
        `;
        return;
    }

    filteredProducts.forEach(product => {
        const card = document.createElement("article");
        card.className = "product-card";

        card.innerHTML = `
            <div class="product-image-wrap">
                <img
                    class="product-image"
                    src="${product.image}"
                    alt="${product.name}"
                    loading="lazy"
                >
                <span class="product-badge">
                    ${product.badge}
                </span>
            </div>

            <div class="product-info">
                <h3>${product.name}</h3>

                <p class="product-description">
                    ${product.description}
                </p>

                <div class="product-bottom">
                    <span class="product-price" id="price-${product.id}">
                        ${formatPrice(product.price)}
                        <span class="price-unit">/ 250g</span>
                    </span>
                </div>

                <div class="product-options">
                    <label for="size-${product.id}">
                        Choose pack size
                    </label>

                    <select id="size-${product.id}" class="pack-size">
                        <option value="250g">250 g</option>
                        <option value="500g">500 g</option>
                        <option value="1kg">1 kg</option>
                    </select>
                </div>

                <button
                    class="add-cart-button"
                    data-product-id="${product.id}"
                >
                    + Add to Cart
                </button>
            </div>
        `;

        const image = card.querySelector(".product-image");

        // Show a fallback if the remote image is unavailable.
        image.addEventListener("error", () => {
            image.style.display = "none";
            image.parentElement.style.background =
                "linear-gradient(135deg, #e8efd9, #f6e2bd)";
            image.parentElement.insertAdjacentHTML(
                "beforeend",
                '<span style="display:grid;place-items:center;height:100%;font-size:54px" aria-label="Pickle">🥭</span>'
            );
        }, { once: true });

        productGrid.appendChild(card);
    });
}

/* ==========================================
   4. CATEGORY FILTERING
========================================== */

categoryFilters.addEventListener("click", event => {
    const button = event.target.closest("[data-category]");

    if (!button) return;

    activeCategory = button.dataset.category;

    document.querySelectorAll(".category-button").forEach(item => {
        const isActive = item === button;

        item.classList.toggle("active", isActive);
        item.setAttribute("aria-pressed", String(isActive));
    });

    renderProducts();
});

sortProducts.addEventListener("change", renderProducts);

/* ==========================================
   5. PACK SIZE PRICE UPDATES
========================================== */

productGrid.addEventListener("change", event => {
    if (!event.target.matches(".pack-size")) return;

    const select = event.target;
    const productId = Number(select.id.replace("size-", ""));
    const product = products.find(item => item.id === productId);

    if (!product) return;

    const price = getPackPrice(product, select.value);
    const priceElement = document.getElementById(
        `price-${product.id}`
    );

    if (priceElement) {
        priceElement.innerHTML = `
            ${formatPrice(price)}
            <span class="price-unit">/ ${select.value}</span>
        `;
    }
});

/* ==========================================
   6. ADD PRODUCTS TO CART
========================================== */

productGrid.addEventListener("click", event => {
    const button = event.target.closest(".add-cart-button");

    if (!button) return;

    const productId = Number(button.dataset.productId);
    const product = products.find(item => item.id === productId);

    if (!product) return;

    const sizeSelect = document.getElementById(
        `size-${productId}`
    );

    const size = sizeSelect.value;
    const price = getPackPrice(product, size);

    // Same product and same size share one cart line.
    const existingItem = cart.find(item =>
        item.productId === productId && item.size === size
    );

    if (existingItem) {
        existingItem.quantity += 1;
    } else {
        cart.push({
            productId: product.id,
            name: product.name,
            size,
            price,
            quantity: 1
        });
    }

    renderCart();
    showToast(`${product.name} added to your cart!`);
});

/* ==========================================
   7. CART DISPLAY
========================================== */

function renderCart() {
    const totalQuantity = cart.reduce(
        (total, item) => total + item.quantity,
        0
    );

    const subtotal = cart.reduce(
        (total, item) => total + item.price * item.quantity,
        0
    );

    cartCount.textContent = totalQuantity;
    cartSubtotal.textContent = formatPrice(subtotal);

    cartItems.innerHTML = "";

    if (cart.length === 0) {
        cartItems.innerHTML = `
            <div class="cart-empty">
                <p>Your cart is empty.</p>
                <p>Add your favourite pickles to get started!</p>
            </div>
        `;

        checkoutButton.disabled = true;
        checkoutButton.style.opacity = "0.5";
        checkoutButton.style.cursor = "not-allowed";
        return;
    }

    checkoutButton.disabled = false;
    checkoutButton.style.opacity = "1";
    checkoutButton.style.cursor = "pointer";

    cart.forEach(item => {
        const row = document.createElement("div");
        row.className = "cart-item";

        row.innerHTML = `
            <div>
                <h3>${item.name}</h3>
                <p>${item.size} · ${formatPrice(item.price)} per pack</p>
                <button
                    class="remove-button"
                    data-action="remove"
                    data-product-id="${item.productId}"
                    data-size="${item.size}"
                >
                    Remove
                </button>
            </div>

            <div class="cart-quantity">
                <button
                    class="quantity-button"
                    data-action="decrease"
                    data-product-id="${item.productId}"
                    data-size="${item.size}"
                    aria-label="Decrease quantity"
                >−</button>

                <span>${item.quantity}</span>

                <button
                    class="quantity-button"
                    data-action="increase"
                    data-product-id="${item.productId}"
                    data-size="${item.size}"
                    aria-label="Increase quantity"
                >+</button>
            </div>

            <div class="cart-item-total">
                ${formatPrice(item.price * item.quantity)}
            </div>
        `;

        cartItems.appendChild(row);
    });
}

/* ==========================================
   8. UPDATE OR REMOVE CART ITEMS
========================================== */

cartItems.addEventListener("click", event => {
    const button = event.target.closest("[data-action]");

    if (!button) return;

    const productId = Number(button.dataset.productId);
    const size = button.dataset.size;
    const action = button.dataset.action;

    const index = cart.findIndex(item =>
        item.productId === productId && item.size === size
    );

    if (index === -1) return;

    if (action === "increase") {
        cart[index].quantity += 1;
    }

    if (action === "decrease") {
        cart[index].quantity -= 1;

        if (cart[index].quantity <= 0) {
            cart.splice(index, 1);
        }
    }

    if (action === "remove") {
        cart.splice(index, 1);
    }

    renderCart();
});

/* ==========================================
   9. OPEN AND CLOSE CART
========================================== */

cartButton.addEventListener("click", () => {
    cartSection.hidden = false;
    cartSection.scrollIntoView({
        behavior: "smooth",
        block: "start"
    });
});

closeCart.addEventListener("click", () => {
    cartSection.hidden = true;

    document.getElementById("products").scrollIntoView({
        behavior: "smooth",
        block: "start"
    });
});

/* ==========================================
   10. WHATSAPP CHECKOUT
========================================== */

checkoutButton.addEventListener("click", () => {
    if (cart.length === 0) {
        showToast("Your cart is empty.");
        return;
    }

    if (!/^\d{10,15}$/.test(WHATSAPP_NUMBER) ||
        WHATSAPP_NUMBER.includes("X")) {
        showToast("Please add your real WhatsApp number in script.js.");
        return;
    }

    const subtotal = cart.reduce(
        (total, item) => total + item.price * item.quantity,
        0
    );

    let message = "Hello Vinayaka Pickles! 👋\n";
    message += "I would like to place an order:\n\n";

    cart.forEach((item, index) => {
        message += `${index + 1}. ${item.name}\n`;
        message += `   Pack: ${item.size}\n`;
        message += `   Quantity: ${item.quantity}\n`;
        message += `   Price per pack: ${formatPrice(item.price)}\n`;
        message += `   Amount: ${formatPrice(item.price * item.quantity)}\n\n`;
    });

    message += `Subtotal: ${formatPrice(subtotal)}\n`;
    message += "Please confirm availability, delivery charges and final total. Thank you!";

    const whatsappURL =
        `https://wa.me/${WHATSAPP_NUMBER}?text=${encodeURIComponent(message)}`;

    window.open(whatsappURL, "_blank", "noopener,noreferrer");
});

/* ==========================================
   11. MOBILE NAVIGATION
========================================== */

menuToggle.addEventListener("click", () => {
    const isOpen = navigation.classList.toggle("open");

    menuToggle.setAttribute("aria-expanded", String(isOpen));
    menuToggle.textContent = isOpen ? "✕" : "☰";
});

navigation.addEventListener("click", event => {
    if (event.target.closest("a")) {
        navigation.classList.remove("open");
        menuToggle.setAttribute("aria-expanded", "false");
        menuToggle.textContent = "☰";
    }
});

/* ==========================================
   12. INITIALISE WEBSITE
========================================== */

document.getElementById("currentYear").textContent =
    new Date().getFullYear();

document.querySelectorAll(".category-button").forEach(button => {
    button.setAttribute(
        "aria-pressed",
        String(button.dataset.category === "all")
    );
});

renderProducts();
renderCart();
